#!/bin/bash
# ---
# ---  name:   tf_s3_remote_init.sh
# ---  author: ckell <chad_kellerman@troweprice.com>
# ---  date:   Nov 23, 2016
# ---  descr:  This script is run to create the initial S3 bucket that stores the remote state to terraform
# ---          for this particular applications component.
# ---  notes: Only buckets and objects can be tagged.  So help with TCO we need to uniquify the bucket name and tag it appropriately.
# ---         s3://github-org.github-repo.aws_account/region-tfstate/uniquifier
# ---         Where the bucket:       1. is properly tagged
# ---                                 2. versioning is enabled.
# ---                                 3. Cross-region replicaiton is enabled to us-west-1 when it's becomes available.
# ---
# ---         Where the key/folders:  1. use standard storage
# ---                                 2. Server side encryption (AES-256) is enabled.  Until Terraform enterprise
# ---
# ---         Where is uniquifier is: 1. "_" for the gold copy of the deployed application in each region
# ---                                 2. "app_id" for developer deployments in dev.

# --- globals
SCRIPT="tf_s3_remote_init.sh"
HOSTNAME=`uname -n`

# --- simple logger to give me an idea of what's happening when.
logger()
{
    mesg=$1
    echo "${SCRIPT} - ${mesg}"
}

bucket_exists () {
  logger "checking if s3://$bucket_name --profile=$aws_profile bucket exists:"
  BUCKET_EXISTS=true
  S3_CHECK=$(aws s3 ls "s3://$bucket_name" --profile=$aws_profile 2>&1)

  if [ $? != 0 ];then
    NO_BUCKET_CHECK=$(echo $S3_CHECK | grep -c 'NoSuchBucket')
    if [ $NO_BUCKET_CHECK = 1 ]; then
      echo "Bucket does not exist"
      return 1
    else
      echo "Error checking S3 Bucket"
      echo "$S3_CHECK"
      exit 1
    fi
  else
    echo "Bucket exists"
  fi     
}

create_bucket () {
  logger "creating bucket s3://$bucket_name in $aws_region"
  aws s3api create-bucket --bucket $bucket_name --profile=$aws_profile --region=$aws_region --acl private
  if [ $? -ne 0 ]; then
      logger "ERROR: s3://$bucket_name bucket creation failed"
      logger "Please investigate."
      exit 2
  fi

  sleep 2  # --- give aws time to create it

  logger "enabling versioning on s3://$bucket_name"
  aws s3api put-bucket-versioning --bucket $bucket_name --versioning-configuration Status=Enabled --profile=$aws_profile --region=$aws_region
  if [ $? -ne 0 ]; then
      logger "ERROR: enabling versioning on s3://$bucket_name failed"
      logger "Please investigate."
      exit 2
  fi

  logger "assigning the apropriate tags on the bucket"
  aws s3api put-bucket-tagging --bucket $bucket_name --tagging "TagSet=[{Key=ProjectCode,Value=$tag_project_code},{Key=CostCenter,Value=$tag_cost_center},{Key=AppID,Value=$tag_application_id},{Key=AppName,Value=$tag_application_name},{Key=Component,Value=$tag_component},{Key=Name,Value=Terraform state files},{Key=OwnerEmail,Value=$tag_owner_email}]" --profile=$aws_profile --region=$aws_region
  if [ $? -ne 0 ]; then
     logger "ERROR: tagging on s3://$bucket_name failed"
     logger "Please investigate."
     exit 2
  fi
}

# --- should we proceed if there is a .terraform directory
check_local_tf_dir()
{
    if [ -d ./.terraform ];then
      logger "ERROR: .terraform directory exists."
      logger "ERROR: terraform remove state appears to be set up."
      exit 0
    fi
}

# --- a sane place to kick of the actions
main()
{
  logger "starting ${SCRIPT}......"
  check_local_tf_dir
  # --- source the Terraform variables we'll need
  source global.tfvars
  source environment.tfvars

  #bucket_name="$aws_account-$aws_region-tfstate"
  bucket_name="${github_org}.${github_repo}.${aws_account}"
  key_name="${aws_region}-tfstate"
  if bucket_exists
    then
      logger "configure terraform remote config"
      terraform init -backend-config=state.tfconfig

    else
      logger "create bucket and then configure terraform "
      create_bucket
      terraform init -backend-config=state.tfconfig

  fi
  logger "done ${SCRIPT}. exitting, stage right!"
}

# --- do it!
main "$@"

