#!/bin/bash

aws s3 cp --profile trp-usis-dev --region us-east-1 init.txt s3://trp-usis-dev-us-east-1-app-usidigital-analytics/STAGE/TDF/init.txt --acl private --sse AES256
aws s3 cp --profile trp-usis-dev --region us-east-1 init.txt s3://trp-usis-dev-us-east-1-app-usidigital-analytics/CERTIFIED/TDF/init.txt --acl private --sse AES256

