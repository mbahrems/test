#!/bin/bash

# aws s3 rb --profile trp-usis-dev --region us-east-1 s3://us-institutional.digital-analytics.trp-usis-dev --force
aws s3 rm --profile trp-usis-dev --region us-east-1 s3://us-institutional.digital-analytics.trp-usis-dev/* --recursive

export AWS_PROFILE="trp-usis-dev"
export AWS_REGION="us-east-1"
# export BUCKET="trp-usis-dev-us-east-1-app-usidigital-analytics"
export BUCKET="us-institutional.digital-analytics.trp-usis-dev"

# step 1:
# aws s3api list-object-versions --profile $AWS_PROFILE --region $AWS_REGION --bucket $BUCKET | jq '{Objects: [.Versions[] | {Key:.Key, VersionId : .VersionId}], Quiet: false}' > mydelete.json

# step 2:
# aws s3api list-object-versions --profile $AWS_PROFILE --region $AWS_REGION --bucket $BUCKET | jq '{Objects: [.DeleteMarkers[] | {Key:.Key, VersionId : .VersionId}], Quiet: false}' > mydelete.json

# aws s3api delete-objects --profile $AWS_PROFILE --region $AWS_REGION --bucket $BUCKET --delete file://mydelete.json
